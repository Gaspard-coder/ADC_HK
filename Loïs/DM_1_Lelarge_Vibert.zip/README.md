# Répartition des différents modules du rendu

## DM_ADC.m
Programme principal répondant aux différentes questions et faisant appel aux fonctions annexes.

## CAN.m
Fonction modélisant un CAN

## calc_spectre.m
Fonction calculant le spectre d'un signal donné.

## calc_SNR_freq.m
Fonction calculant le SNR avec une approche fréquentielle.

